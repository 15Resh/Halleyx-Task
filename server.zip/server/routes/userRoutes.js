// server/routes/userRoutes.js
import express from 'express';
import { getAllUsers } from '../controllers/userController.js';
import verifyToken from '../middlewares/verifyToken.js';
import { isAdmin } from '../middlewares/isAdmin.js';

const router = express.Router();

// Route to get all users, protected and admin-only
router.get('/users', verifyToken, isAdmin, getAllUsers);

export default router;
