// server/routes/orderRoutes.js
import express from 'express';
import { getAllOrders } from '../controllers/orderController.js';
import verifyToken from '../middlewares/verifyToken.js';
import { isAdmin } from '../middlewares/isAdmin.js';

const router = express.Router();

// Route to get all orders, protected and admin-only
router.get('/orders', verifyToken, isAdmin, getAllOrders);

export default router;


