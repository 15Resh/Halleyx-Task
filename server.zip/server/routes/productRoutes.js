import express from 'express';
import {
  getAllProducts,
  createProduct,
  updateProduct,
  deleteProduct
} from '../controllers/productController.js';

import { protect, isAdmin } from '../middlewares/authMiddleware.js';

const router = express.Router();

router.get('/admin/products', protect, isAdmin, getAllProducts);
router.post('/admin/products', protect, isAdmin, createProduct);
router.put('/admin/products/:id', protect, isAdmin, updateProduct);
router.delete('/admin/products/:id', protect, isAdmin, deleteProduct);

export default router;
