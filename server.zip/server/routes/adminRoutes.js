import express from 'express'
import { getAllUsers, deleteUser } from '../controllers/adminController.js'
import verifyToken from '../middlewares/verifyToken.js'
import { isAdmin } from '../middlewares/isAdmin.js'

const router = express.Router()

// Example: Admin-only routes
router.get('/users', verifyToken, isAdmin, getAllUsers)
router.delete('/users/:id', verifyToken, isAdmin, deleteUser)

export default router
