import dotenv from 'dotenv'
dotenv.config()

import express from 'express'
import cors from 'cors'
import cookieParser from 'cookie-parser'

import adminRoutes from './routes/adminRoutes.js';
import authRouter from './routes/authRoutes.js'
import connectDb from './config/db.js'
import cartRouter from './routes/cartRoutes.js'
import productRoutes from './routes/productRoutes.js'
import userRoutes from './routes/userRoutes.js'
import orderRoutes from './routes/orderRoutes.js'

const app = express()
const port = process.env.PORT || 5000;


connectDb()

app.use(express.json())
app.use(cors({
  origin: ['http://localhost:5173', process.env.ORIGIN, 'https://shopping-cart-mern-yo9j.vercel.app'],
  credentials: true
}));

app.use(cookieParser())

app.use('/api/auth', authRouter)
app.use('/api/cart', cartRouter)
app.use('/api/products', productRoutes)
app.use('/api/admin', adminRoutes)
app.use('/api/orders', orderRoutes);
app.use('/api/users', userRoutes);

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.listen(port, () => {
  console.log(`Server listening on port ${port}`)
})
