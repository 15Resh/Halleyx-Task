// server/controllers/userController.js
import User from '../models/userModel.js';

// Get all users (exclude passwords)
export const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('-password'); // exclude passwords for security
    res.status(200).json({ success: true, users });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// You can add more user-related controller functions here if needed
