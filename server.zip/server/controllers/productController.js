import Product from '../models/productModel.js';

// Get all products (admin)
export const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find();
    res.status(200).json({ success: true, products });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Create a new product
export const createProduct = async (req, res) => {
  console.log("🔧 Request received to create a product.");
  console.log("📦 Request body:", req.body);
  console.log("🧑‍💼 User info (from token):", req.user);

  const { name, description, price, image, category, stock } = req.body;

  if (!name || !price) {
    console.log("❌ Missing required fields");
    return res.status(400).json({ success: false, message: "Name and price are required." });
  }

  try {
    const product = new Product({
      name,
      description,
      price,
      image,
      category,
      stock
    });

    await product.save();
    console.log("✅ Product created successfully:", product);

    res.status(201).json({ success: true, product });
  } catch (error) {
    console.log("🔥 Error:", error.message);
    res.status(500).json({ success: false, message: error.message });
  }
};

// Update product by id
export const updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const product = await Product.findByIdAndUpdate(id, updates, { new: true });
    if (!product) return res.status(404).json({ success: false, message: "Product not found" });
    res.status(200).json({ success: true, product });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Delete product by id
export const deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findByIdAndDelete(id);
    if (!product) return res.status(404).json({ success: false, message: "Product not found" });
    res.status(200).json({ success: true, message: "Product deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
