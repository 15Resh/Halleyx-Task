import mongoose from 'mongoose'

const orderSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'user',
    required: true
  },
  orderItems: [
    {
      id: String,
      title: String,
      image: String,
      price: Number,
      quantity: Number
    }
  ],
  totalAmount: Number,
  status: {
    type: String,
    default: 'Processing'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
})

const Order = mongoose.model('order', orderSchema)
export default Order
